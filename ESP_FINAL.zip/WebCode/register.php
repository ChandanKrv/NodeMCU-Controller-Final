<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="style_login.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Favicon -->
  <link href="img/icons/icon.jpg" rel="shortcut icon"/>
</head>
<body>
	<img class="wave" src="wave.png">
	<div class="container">
		<div class="img">
			<img src="bg.svg">
		</div>
		<div class="login-content">
      <?php
  session_start();
  if(isset($_SESSION['uid'])){
    header("location:home.php");
    exit;
  }
?>
			<form action="allfunction.php" method="post">
				<img src="avatar.svg">
				<h2 class="title">Welcome</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>First Name</h5>
           		   		<input type="text" class="input" name="fName" required="">
           		   </div>
           		</div>

                <div class="input-div one">
                 <div class="i">
                    <i class="fas fa-user"></i>
                 </div>
                 <div class="div">
                    <h5>Last Name</h5>
                    <input type="text" class="input" name="lName" required="">
                 </div>
              </div>

              <div class="input-div one">
                 <div class="i">
                    <i class="fas fa-envelope"></i>
                 </div>
                 <div class="div" >
                    <h5>10 Digits Mobile Number</h5>
                    <input type="number" class="input" name="phNo" required="" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "10" >
                    
                 </div>
              </div>
             <h5>Must use same phone number in ESP board.</h5>
              <div class="input-div pass">
                 <div class="i"> 
                    <i class="fas fa-lock"></i>
                 </div>
                 <div class="div">
                    <h5>Password</h5>
                    <input type="password" name="pass" class="input" required="">
                 </div>
              </div>             
              
           		
            	<a href="index.php">Login to your Account </a>
            	<input type="submit" class="btn" name="register" value="Register">
            </form>
        </div>
    </div>
    <script type="text/javascript" src="main_login.js"></script>
</body>
</html>
