<?php
  
$serverName = "localhost";
    $dbname = "candyapkof_node";
	$username = "candyapkof_user";
    $password = "Chandan@123";

   $conn = mysqli_connect("$serverName", "$username", "$password", "$dbname");
	    
 
	?>