<?php
session_start();
include_once('iotDatabase.php');

$result = getAllOutputs();
$html_buttons = null;
if ($result) {
    while ($row = $result->fetch_assoc()) {
        if ($row["state"] == "1") {
            $button_checked = "checked";
        } else {
            $button_checked = "";
        }
        $html_buttons .= '<h3>' . $row["sName"] . ' - Board ' . $row["boardNo"] . ' - GPIO ' . $row["gpio"] . ' (<i><a onclick="deleteOutput(this)" href="javascript:void(0);" id="' . $row["sId"] . '">Delete</a></i>)</h3><label class="switch"><input type="checkbox" onchange="updateOutput(this)" id="' . $row["sId"] . '" ' . $button_checked . '><span class="slider"></span></label>';
    }
}

?>

<?php


if (!isset($_SESSION['iotph'])) {
    echo "<script>window.open('index.php','_self')</script>";
} else {

?>

    <!DOCTYPE HTML>
    <html>

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="espStyle.css">
        <title>NodeMCU Controller</title>
    </head>

    <body bgcolor="lightgray">

        <h2>ESP Controller</h2>
        <?php $phNo = $_SESSION['iotph'];

        $selectUserId = "SELECT * FROM users WHERE phNo = '$phNo'";
        $runUserID = mysqli_query($con, $selectUserId);
        while ($rowUser = mysqli_fetch_array($runUserID)) {
            $fName = $rowUser['fName'];
            $lName = $rowUser['lName'];
        }

        echo "Welcome: " . $fName . " " . $lName;

        ?>
        <a href="logout.php"> (Logout)</a>
        <?php echo $html_buttons; ?>
        <br><br>

        <div>
            <form onsubmit="return createOutput();">
                <h3>Create New Switch</h3>
                <label for="outputName">Switch Name</label>
                <input type="text" name="name" id="outputName"><br>
                <label for="outputBoard">Board Number [Must be same as entered in ESP board]</label>
                <input type="number" name="board"  oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "1" id="outputBoard">
                <label for="outputGpio">GPIO Pin Number </label><a href="nodeMCU.jpg" target="_blank">See</a>
                <input type="number" name="gpio" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength = "2" id="outputGpio">
                <label for="outputState">Initial Switch State</label>
                <select id="outputState" name="state">
                    <option value="0">OFF</option>
                    <option value="1">ON</option>
                </select>
                <input type="submit" value="Create Now">
                <p><strong>Note:</strong> in some devices, you might need to refresh the page to see your newly created buttons or to remove deleted buttons.</p>
            </form>
        </div>

        <script>
            function updateOutput(element) {
                var xhr = new XMLHttpRequest();
                if (element.checked) {
                    xhr.open("GET", "esp-outputs-action.php?action=output_update&id=" + element.id + "&state=1", true);
                } else {
                    xhr.open("GET", "esp-outputs-action.php?action=output_update&id=" + element.id + "&state=0", true);
                }
                xhr.send();
            }

            function deleteOutput(element) {
                var result = confirm("Want to delete this output?");
                if (result) {
                    var xhr = new XMLHttpRequest();
                    xhr.open("GET", "esp-outputs-action.php?action=output_delete&id=" + element.id, true);
                    xhr.send();
                    //alert("Output deleted");
                    setTimeout(function() {
                        window.location.reload();
                    });
                }
            }

            function createOutput(element) {
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "esp-outputs-action.php", true);

                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

                xhr.onreadystatechange = function() {
                    if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                        alert("Output created");
                        setTimeout(function() {
                            window.location.reload();
                        });
                    }
                }
                var outputName = document.getElementById("outputName").value;
                var outputBoard = document.getElementById("outputBoard").value;
                var outputGpio = document.getElementById("outputGpio").value;
                var outputState = document.getElementById("outputState").value;
                var httpRequestData = "action=output_create&name=" + outputName + "&board=" + outputBoard + "&gpio=" + outputGpio + "&state=" + outputState;
                xhr.send(httpRequestData);
            }
        </script>
    </body>

    </html>
<?php } ?>