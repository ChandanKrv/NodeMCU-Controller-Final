<?php

$serverName = "localhost";
$dbname = "candyapkof_node";
$username = "candyapkof_user";
$password = "Chandan@123";

$con = mysqli_connect("$serverName", "$username", "$password", "$dbname");


function createOutput($phNo, $name, $board, $gpio, $state)
{
    global $serverName, $username, $password, $dbname, $con;


    // Create connection
    $conn = new mysqli($serverName, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

   
         $selectUserId = "SELECT * FROM users WHERE phNo = '$phNo'";
        $runUserID = mysqli_query($con, $selectUserId);
        while ($rowUser = mysqli_fetch_array($runUserID)) {
            $uId = $rowUser['uId'];
        }


        $auth = $board . $phNo;

        $sql = "INSERT INTO switches (uIdFK, auth, phNo, sName, boardNo, gpio, state)
        VALUES ('" . $uId . "', '" . $auth . "', '" . $phNo . "', '" . $name . "', '" . $board . "', '" . $gpio . "', '" . $state . "')";

        if ($conn->query($sql) === TRUE) {
            return "New output created successfully";
        } else {
            return "Error: " . $sql . "<br>" . $conn->error;
        }
        $conn->close();
    
}

function deleteOutput($id)
{
    global $serverName, $username, $password, $dbname;

    // Create connection
    $conn = new mysqli($serverName, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "DELETE FROM switches WHERE sId='" . $id .  "'";

    if ($conn->query($sql) === TRUE) {
        return "Output deleted successfully";
    } else {
        return "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}

function updateOutput($id, $state)
{
    global $serverName, $username, $password, $dbname;

    // Create connection
    $conn = new mysqli($serverName, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "UPDATE switches SET state='" . $state . "' WHERE sId='" . $id .  "'";

    if ($conn->query($sql) === TRUE) {
        return "Output state updated successfully";
    } else {
        return "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}

 function getAllOutputs()
{       global $serverName, $username, $password, $dbname;

    // Create connection
    $conn = new mysqli($serverName, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $phNo = $_SESSION["iotph"];

    $sql = "SELECT sId, sName, boardNo, gpio, state FROM switches WHERE phNo='$phNo' ORDER BY boardNo";
    if ($result = $conn->query($sql)) {
        return $result;
    } else {
        return false;
    }
    $conn->close();
} 

function getAllOutputStates($auth)
{
    global $serverName, $username, $password, $dbname;

    // Create connection
    $conn = new mysqli($serverName, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT gpio, state FROM switches WHERE auth='" . $auth . "'";
    if ($result = $conn->query($sql)) {
        return $result;
    } else {
        return false;
    }
    $conn->close();
}

 function getOutputBoardById($id)
{
    global $serverName, $username, $password, $dbname;

    // Create connection
    $conn = new mysqli($serverName, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT boardNo FROM switches WHERE sId='" . $id . "'";
    if ($result = $conn->query($sql)) {
        return $result;
    } else {
        return false;
    }
    $conn->close();
} 

/* function deleteBoard($boardNo)
{
    session_start();

    global $serverName, $username, $password, $dbname;

    // Create connection
    $conn = new mysqli($serverName, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $phNo = $_SESSION["iotph"];

    $sql = "DELETE FROM switches WHERE phNo='" . $phNo .  "' AND boardNo='" . $boardNo .  "'";

    if ($conn->query($sql) === TRUE) {
        return "Board deleted successfully";
    } else {
        return "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}  */
