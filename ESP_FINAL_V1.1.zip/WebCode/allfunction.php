<?php
    session_start();
	
	include_once('connection.php');

       //Register data esp module
	if(isset($_POST['register'])){
		$fName = $_POST['fName'];
		$lName = $_POST['lName'];
		$phNo = $_POST['phNo'];
		$pass = $_POST['pass'];

		//$phInt =(int)$phNo;

		$get_users = "select * from users where phNo=$phNo";
                $run_users = mysqli_query($conn, $get_users);
                $count = mysqli_num_rows($run_users);
                if ($count) {
			echo "<script>alert('You Are Already Registered, Login Now')</script>";
			echo "<script>location.href='index.php'</script>";
		}else{

		$sql = "INSERT INTO users (`fName`,`lName`,`phNo`,`pass`) VALUES ('".$fName."','".$lName."','".$phNo."','".$pass."')";

		if($conn->query($sql)){
			//echo "<script>alert('Registered Successfully!!')</script>";
			$_SESSION['iotph'] = $phNo;
			echo "<script>location.href='welcome.php'</script>";
			
		}else{
			echo "<script>alert('Registration Error !!')</script>";
			echo "<script>location.href='register.php'</script>";
		}
	}	
	}


 //Login check
 if(isset($_POST['login'])){	
   
   $phNo = $_POST['phNo'];
   $pass = $_POST['pass']; 

   $sql= "SELECT * from users where phNo='$phNo' AND pass ='$pass' ";
   $result=mysqli_query($conn,$sql);
   
   $count=mysqli_num_rows($result);
   if($count >0){
       // echo "<script>alert('Logged in Successfully!!')</script>";
        $_SESSION['iotph'] = $phNo;
	    echo "<script>location.href='welcome.php'</script>";
   }   
   else{
        echo "<script>alert('Incorrect Mobile Number or Password')</script>";
	    echo "<script>location.href='index.php'</script>";
   }

 }
?>